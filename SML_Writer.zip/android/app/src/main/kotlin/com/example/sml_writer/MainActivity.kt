package com.example.sml_writer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
